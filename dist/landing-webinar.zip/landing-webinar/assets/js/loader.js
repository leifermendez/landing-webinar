// Wait for window load
$(window).on('load', function () {
    // Animate loader off screen
    $(".hiro-loader").fadeOut("slow");;
});